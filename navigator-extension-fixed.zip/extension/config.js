// Convex configuration
var CONVEX_URL = "https://abundant-porpoise-181.convex.cloud";
